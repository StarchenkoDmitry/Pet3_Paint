const canv = document.getElementById("canvas");
const ctx  = canvas.getContext('2d');

const articleDiv = document.querySelector(".palitra-list");

const doc_cords = document.getElementById("block-cords");

let curentColor = "rgb(0, 0, 0)";


const Instrument_Pencil = Symbol();
const Instrument_Fill = Symbol();
const Instrument_Pipetka = Symbol();
const Instrument_Lastik = Symbol();
const Instrument_Text = Symbol();


const palitraCount = 20;
const stepColor = 255/palitraCount;
for(let p =0;p < palitraCount;p++){
    let str2 = `<div class="palitra-item">
<div class="palitra-item-color" style="background-color: rgb(${0},${0}, ${(stepColor*(p+1))});"></div>
</div>`;
    articleDiv.innerHTML+=str2;
}
Array.from(document.getElementsByClassName("palitra-item-color")).forEach(e =>{
  e.addEventListener("click",()=>{
    // console.dir(e.style.backgroundColor);
    curentColor = e.style.backgroundColor;
  });
  console.log("1");
  e.addEventListener('contextmenu', (e) => {  console.log(e); e.preventDefault(); });
});



canv.onmouseover = (event) =>  {
  mouseCordsOnCanvas.isOver =true;
}
canv.onmouseout = (event) =>  {
  mouseCordsOnCanvas.isOver =false;
  doc_cords.innerHTML = `(0, 0)px`;
}






let mouseCordsOnCanvas={
  isDown: false,
  isOver: false,
  x:0,
  y:0,
  x_old:0,
  y_old:0,
}

canv.onmousedown = function(event) {

  const x = event.offsetX;
  const y = event.offsetY;
  mouseCordsOnCanvas.isDown = true;
  mouseCordsOnCanvas.x = x;
  mouseCordsOnCanvas.y = y;
  mouseCordsOnCanvas.x_old = x;
  mouseCordsOnCanvas.y_old = y;
  
  //console.log(`down ${x}, ${y}`);
}

canv.onmousemove = function(event){
  mouseCordsOnCanvas.x_old = mouseCordsOnCanvas.x;
  mouseCordsOnCanvas.y_old = mouseCordsOnCanvas.y;
  const x = event.offsetX;
  // console.dir(event.target);
  const y = event.offsetY;

  mouseCordsOnCanvas.x = x;
  mouseCordsOnCanvas.y = y;

  if(mouseCordsOnCanvas.isDown){        
    const width = 10;
    
    ctx.beginPath();
    ctx.moveTo(mouseCordsOnCanvas.x_old, mouseCordsOnCanvas.y_old);
    ctx.lineTo(mouseCordsOnCanvas.x, mouseCordsOnCanvas.y);
    ctx.strokeStyle = curentColor;
    ctx.lineWidth = width;
    ctx.stroke();

    ctx.beginPath();
    ctx.fillStyle = curentColor;
    ctx.arc(mouseCordsOnCanvas.x_old, mouseCordsOnCanvas.y_old, width/2, 0, 2 * Math.PI, true);
    ctx.fill();

    ctx.beginPath();
    ctx.fillStyle = curentColor;
    ctx.arc(mouseCordsOnCanvas.x, mouseCordsOnCanvas.y, width/2, 0, 2 * Math.PI, true);
    ctx.fill();
    
    //console.log(`${mouseCordsOnCanvas.x - mouseCordsOnCanvas.x_old}, ${mouseCordsOnCanvas.y - mouseCordsOnCanvas.y_old}`);
    // if(mouseCordsOnCanvas.x - mouseCordsOnCanvas.x_old === 0 && mouseCordsOnCanvas.y - mouseCordsOnCanvas.y_old === 0){
    //   console.log("нету движение событие фейк");
    // }
  }

  if(mouseCordsOnCanvas.isOver){
    doc_cords.innerHTML = `(${mouseCordsOnCanvas.x}, ${mouseCordsOnCanvas.y})px`;
  }
  //console.log(`move ${x}, ${y}`);
}

window.onmouseup = function(event) {
  mouseCordsOnCanvas.isDown = false;  

  var x = event.offsetX;
  var y = event.offsetY;

  mouseCordsOnCanvas.x_old = mouseCordsOnCanvas.x;
  mouseCordsOnCanvas.y_old = mouseCordsOnCanvas.y;

  mouseCordsOnCanvas.x = x;
  mouseCordsOnCanvas.y = y;

  //console.log(`windows up ${x}, ${y}`);
}









// let mouseCordOnPage={
//   x: 0,
//   y: 0
// };

//setInterval(()=>{ console.log(`cords: ${mouseCordOnPage.x}, ${mouseCordOnPage.y}`);},300);

// document.onmousemove = function(e){
//   if (!e) e = window.event;
//   if (e.pageX){
//     mouseCordOnPage.x = e.pageX;
//   }
//   if (e.pageY){
//     mouseCordOnPage.y = e.pageY;
//   }
// }







// draw();
// function draw() {
//   for(var i=0;i<4;i++){
//     for(var j=0;j<3;j++){
//       ctx.beginPath();
//       var x = 25+j*50; // x coordinate
//       var y = 25+i*50; // y coordinate
//       var radius = 20; // Arc radius
//       var startAngle = 0; // Starting point on circle
//       var endAngle = Math.PI+(Math.PI*j)/2; // End point on circle
//       var anticlockwise = i%2==0 ? false : true; // clockwise or anticlockwise

//       ctx.arc(x, y, radius, startAngle, endAngle, anticlockwise);

//       if (i>1){
//         ctx.fill();
//       } else {
//         ctx.stroke();
//       }
//     }
//   }  
// }


















// var canvas = document.getElementById('canvas');
// if (canvas.getContext)
// {
//   var ctx = canvas.getContext('2d');
//   ctx.beginPath();
//   ctx.moveTo(75,50);
//   ctx.lineTo(100,75);
//   ctx.lineTo(100,25);
//   ctx.fill();
// }





// document.onmousemove = function(e)
// {
  
// 	if (!e) e = window.event;
//     if (e.pageX)
//     {
//         console.log("xp:" + e.pageX);
//     }
//     else if (e.clientX)
//     {
//         console.log("xc:" + e.clientX);
//        // return e.clientX+(document.documentElement.scrollLeft || document.body.scrollLeft) - document.documentElement.clientLeft;
//     }

//     if (e.pageY)
//     {
//         console.log("yp:" + e.pageY);
//     }
//     else if (e.clientY)
//     {
//         console.log("yc:" + e.clientY);
//        // return e.clientX+(document.documentElement.scrollLeft || document.body.scrollLeft) - document.documentElement.clientLeft;
//     }

// }




// создаем элемент
// var elem = document.createElement("p");
// // создаем для него текст
// var elemText = document.createTextNode("Привет мир");
// // добавляем текст в элемент в качестве дочернего элемента
// elem.appendChild(elemText);
// // добавляем элемент в блок div
// articleDiv.appendChild(elem);