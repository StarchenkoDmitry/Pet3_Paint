const canv = document.getElementById("canvas");
const ctx  = canv.getContext('2d');

const articleDiv = document.getElementById("palitra-list");
const doc_cords = document.getElementById("block-cords");

let curentColorL = "rgb(50, 50, 50)";
let curentColorR = "rgb(255, 255, 255)";

const Element_mouseL = document.getElementById("mouseL");
const Element_mouseR = document.getElementById("mouseR");
Element_mouseL.style.backgroundColor = curentColorL;
Element_mouseR.style.backgroundColor = curentColorR;

const currentHeaderHeight = document.getElementById("header").clientHeight;
const currentMainDrawWidth = document.getElementById("main-draw").clientWidth;
const currentMainDrawHeight = document.getElementById("main-draw").clientHeight;

const canvDefMinWidth = 100;
const canvDefMinHeight = 100;
const borderForCanv = 20;
const cavnDefX = currentHeaderHeight+(borderForCanv/2);
const cavnDefY = borderForCanv/2;
const canvWidth = currentMainDrawWidth> canvDefMinWidth? currentMainDrawWidth-borderForCanv : canvDefMinWidth;
const canvHeight = currentMainDrawHeight> canvDefMinHeight? currentMainDrawHeight-borderForCanv : canvDefMinHeight;
canv.style.width = `${canvWidth}px`;
canv.style.height =`${canvHeight}px`;
canv.style.top = `${cavnDefX}px`;
canv.style.left = `${cavnDefY}px`;
canv.width = canvWidth
canv.height = canvHeight;




const Instrument_Pencil = Symbol();
const Instrument_Fill = Symbol();
const Instrument_Pipetka = Symbol();
const Instrument_Lastik = Symbol();
const Instrument_Text = Symbol();


const palitraCount = 20;
const stepColor = 255/palitraCount;
for(let p =0;p < palitraCount;p++){
    articleDiv.innerHTML+=createElementColorFromRGB(0,0,(stepColor*(p+1)));
}

function createElementColorFromRGB(r,g,b){
  return `<div class="palitra-item">
  <div class="palitra-item-color" style="background-color: rgb(${r},${g}, ${b});"></div>
  </div>`;
}

function setColorMouseL(str){
  curentColorL = str;
  Element_mouseL.style.backgroundColor = curentColorL;
}

function setColorMouseR(str){
  curentColorR = str;
  Element_mouseR.style.backgroundColor = curentColorR;
}

Array.from(document.getElementsByClassName("palitra-item-color")).forEach(e =>{
  e.addEventListener("click",()=>{
    setColorMouseL(e.style.backgroundColor);
  });
  e.addEventListener('contextmenu', (event) => {
    setColorMouseR(e.style.backgroundColor);
    event.preventDefault(); 
  });
});

canv.addEventListener('contextmenu', (e) => {
  e.preventDefault(); 
});

canv.onmouseover = (event) =>  {
  mouseCordsOnCanvas.isOver =true;
}
canv.onmouseout = (event) =>  {
  mouseCordsOnCanvas.isOver =false;
  doc_cords.innerHTML = "";/*`(0, 0)px`;*/
}



const Control_None = Symbol();
const Control_Tools = Symbol();
const Control_Sizing = Symbol();

let currentControl = Control_None;



window.onmouseover = (e)=>{
  mouseCordsOnCanvas.isOnPage = true;
  mouseCordsOnCanvas.x_page_old = e.pageX;
  mouseCordsOnCanvas.y_page_old = e.pageY;
  mouseCordsOnCanvas.x_page = e.pageX;
  mouseCordsOnCanvas.y_page = e.pageY;
}
window.onmouseout = (e)=>{
  if(!e.toElement){ 
    mouseCordsOnCanvas.isOnPage = false;
    
    mouseCordsOnCanvas.x_page_old = e.pageX;
    mouseCordsOnCanvas.y_page_old = e.pageY;
    mouseCordsOnCanvas.x_page = e.pageX;
    mouseCordsOnCanvas.y_page = e.pageY;
  }
}
window.onmousemove = (e)=>{
  mouseCordsOnCanvas.x_page_old = mouseCordsOnCanvas.x_page;
  mouseCordsOnCanvas.y_page_old = mouseCordsOnCanvas.y_page;
  mouseCordsOnCanvas.x_page = e.pageX;
  mouseCordsOnCanvas.y_page = e.pageY;
  // console.log(`${e.pageX}, ${e.pageY}, ${mouseCordsOnCanvas.isOnPage}`);
}
window.onmousedown = (e)=>{
  mouseCordsOnCanvas.isDownOnPage = true;
}

window.onmouseup = function(e) {
  mouseCordsOnCanvas.isDown = false;  
  mouseCordsOnCanvas.isDownOnPage = false;  

  var x = e.offsetX;
  var y = e.offsetY;

  mouseCordsOnCanvas.x_old = mouseCordsOnCanvas.x;
  mouseCordsOnCanvas.y_old = mouseCordsOnCanvas.y;

  mouseCordsOnCanvas.x = x;
  mouseCordsOnCanvas.y = y;
  // console.log(`UP: ${e.pageX}, ${e.pageY}`)
}

window.onwheel = (ev)=>{
  // console.dir(ev);
}


// function addP(x, y){
//   const newDiv = document.createElement("divf");
//   //const currentDiv = document.getElementById("div1");
//   document.body.insertBefore(newDiv, null);
//   console.dir(newDiv);
// }
// for(let p = 0;p <1300;p++)
// {
//   addP(1,1);
// }

let curentColorDraw = curentColorL;

let mouseCordsOnCanvas={
  isDownOnPage: false,
  isDown: false,
  isOver: false,

  witchClick: 1,/*From 1 to 3, witch [1,2,3]*/

  isOnPage: true,

  x_page:0,
  y_page:0, 
  x_page_old:0,
  y_page_old:0, 

  // x_begin:0,
  // y_begin:0,
  // x_end:0,
  // y_end:0,

  x:0,
  y:0,
  x_old:0,
  y_old:0,
}



canv.onmousedown = function(event) {
  const x = event.offsetX;
  const y = event.offsetY;
  mouseCordsOnCanvas.isDown = true;
  mouseCordsOnCanvas.x = x;
  mouseCordsOnCanvas.y = y;
  mouseCordsOnCanvas.x_old = x;
  mouseCordsOnCanvas.y_old = y;
}

function drawLine(bx,by,ex,ey, lineColor ,width=10){
  ctx.beginPath();
  ctx.moveTo(bx,by);
  ctx.lineTo(mouseCordsOnCanvas.x, mouseCordsOnCanvas.y);
  ctx.strokeStyle = lineColor;
  ctx.lineWidth = width;
  ctx.stroke();

  ctx.beginPath();
  ctx.fillStyle = lineColor;
  ctx.arc(bx, by, width/2, 0, 2 * Math.PI, true);
  ctx.fill();

  ctx.beginPath();
  ctx.fillStyle = lineColor;
  ctx.arc(ex, ey, width/2, 0, 2 * Math.PI, true);
  ctx.fill();
}

canv.onmousemove = function(event){
  mouseCordsOnCanvas.x_old = mouseCordsOnCanvas.x;
  mouseCordsOnCanvas.y_old = mouseCordsOnCanvas.y;
  const x = event.offsetX;
  const y = event.offsetY;

  mouseCordsOnCanvas.x = x;
  mouseCordsOnCanvas.y = y;

  if(mouseCordsOnCanvas.isDown){        
    const width = 10;
    drawLine(mouseCordsOnCanvas.x_old,mouseCordsOnCanvas.y_old,mouseCordsOnCanvas.x, mouseCordsOnCanvas.y,curentColorDraw,width);    
  }

  if(mouseCordsOnCanvas.isOver){
    doc_cords.innerHTML = `(${mouseCordsOnCanvas.x}, ${mouseCordsOnCanvas.y})px`;
  }
  // console.log(`${event.offsetX}, ${event.offsetY}`)
}
