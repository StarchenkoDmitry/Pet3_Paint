const canv = document.getElementById("canvas");
const ctx  = canv.getContext('2d');

const articleDiv = document.getElementById("palitra-list");
const doc_cords = document.getElementById("block-cords");

let curentColorL = "rgb(0, 0, 255)";
let curentColorR = "rgb(255, 0, 0)";

// let curentColorDraw = curentColorL;

const Element_mouseL = document.getElementById("mouseL");
const Element_mouseR = document.getElementById("mouseR");
Element_mouseL.style.backgroundColor = curentColorL;
Element_mouseR.style.backgroundColor = curentColorR;

const currentHeaderHeight = document.getElementById("header").clientHeight;
const currentMainDrawWidth = document.getElementById("main-draw").clientWidth;
const currentMainDrawHeight = document.getElementById("main-draw").clientHeight;

const canvCords={
  top: 0,
  left: 0,
}

// const Max_Sizing = 2*2*2*2;
// const Min_Sizing = .5*.5*.5;
// console.log(Max_Sizing);
// console.log(Min_Sizing);

const canvDefMinWidth = 100;
const canvDefMinHeight = 100;
const borderForCanv = 20;
const cavnDefY= currentHeaderHeight+(borderForCanv/2);
const cavnDefX = borderForCanv/2;
const canvWidth = currentMainDrawWidth> canvDefMinWidth? currentMainDrawWidth-borderForCanv : canvDefMinWidth;
const canvHeight = currentMainDrawHeight> canvDefMinHeight? currentMainDrawHeight-borderForCanv : canvDefMinHeight;

setSizeCanvStyle(canvWidth,canvHeight);
setCanvTopLeft(cavnDefX,cavnDefY);

canv.width = canvWidth;
canv.height = canvHeight;


console.log(canv.offsetLeft);
console.log(canv.style.left);

function setCanvTopLeft(left,top){
  canvCords.top = top;
  canvCords.left = left;
  canv.style.top = `${top}px`;
  canv.style.left = `${left}px`;
}
function getCanvTopLeft(){
  return {top: parseFloat(canv.style.top),left:parseFloat(canv.style.left) };
}
function setSizeCanvStyle(width, height){
  canv.style.width = `${width}px`;
  canv.style.height =`${height}px`;
}
function setSizeCanv(width, height){
  canv.width = width
  canv.height = height;
}


const mouseCords={
  isDown: false,
  isOver: false,

  isAltDown: false,
  isShiftDown: false,

  isDownOnPage: false,
  whichClick: 1,/*From 1 to 3, witch [1,2,3]*/

  isOnPage: true,

  x_page:0,
  y_page:0,
  x_page_old:0,
  y_page_old:0,
}



const Instrument_Pencil = Symbol();
const Instrument_Fill = Symbol();
const Instrument_Pipetka = Symbol();
const Instrument_Lastik = Symbol();
const Instrument_Text = Symbol();


const palitraCount = 20;
const stepColor = 255/palitraCount;
for(let p =0;p < palitraCount;p++){
    articleDiv.innerHTML+=createElementColorFromRGB(0,0,(stepColor*(p+1)));
}

function createElementColorFromRGB(r,g,b){
  return `<div class="palitra-item">
  <div class="palitra-item-color" style="background-color: rgb(${r},${g}, ${b});"></div>
  </div>`;
}

function setColorMouseL(str){
  curentColorL = str;
  Element_mouseL.style.backgroundColor = curentColorL;
}

function setColorMouseR(str){
  curentColorR = str;
  Element_mouseR.style.backgroundColor = curentColorR;
}

Array.from(document.getElementsByClassName("palitra-item-color")).forEach(e =>{
  e.addEventListener("click",()=>{
    setColorMouseL(e.style.backgroundColor);
  });
  e.addEventListener('contextmenu', (event) => {
    setColorMouseR(e.style.backgroundColor);
    event.preventDefault(); 
  });
});

canv.addEventListener('contextmenu', (e) => {
  e.preventDefault(); 
});

canv.onmouseover = (event) =>  {
  mouseCords.isOver =true;
  console.dir(event);
}
canv.onmouseout = (event) =>  {
  mouseCords.isOver =false;

  doc_cords.innerHTML = "";/*`(0, 0)px`;*/
}

const canvMoveCoficent = .2;
function canvMove(deltaTop, deltaLeft){
  const currentRect = getCanvTopLeft();
  setCanvTopLeft(currentRect.left + deltaLeft*canvMoveCoficent,currentRect.top + deltaTop * canvMoveCoficent);
}

// const Control_None = Symbol();
// const Control_Tools = Symbol();
// const Control_Sizing = Symbol();
// let currentControl = Control_None;

const CONST_Ket_Shift = 16;
const CONST_Ket_Alt = 18;

window.onkeydown = (e)=>{
  if(e.keyCode === CONST_Ket_Shift){
    mouseCords.isShiftDown = true;
  }
  if(e.keyCode === CONST_Ket_Alt){
    mouseCords.isAltDown = true;
  }
}

window.onkeyup = (e)=>{
  if(e.keyCode === CONST_Ket_Shift){
    mouseCords.isShiftDown = false;
  }
  if(e.keyCode === CONST_Ket_Alt){
    mouseCords.isAltDown = false;
  }
}


window.onwheel = (ev)=>{
  if(!mouseCords.isAltDown){
    if(mouseCords.isShiftDown){
      canvMove(0, ev.deltaY);  
    }
    else{
      canvMove(ev.deltaY, 0);  
    }
  }
}


window.onmouseover = (e)=>{
  mouseCords.isOnPage = true;
  mouseCords.x_page_old = e.pageX;
  mouseCords.y_page_old = e.pageY;
  mouseCords.x_page = e.pageX;
  mouseCords.y_page = e.pageY;
}
window.onmouseout = (e)=>{
  if(!e.toElement){ 
    mouseCords.isOnPage = false;
    
    mouseCords.x_page_old = e.pageX;
    mouseCords.y_page_old = e.pageY;
    mouseCords.x_page = e.pageX;
    mouseCords.y_page = e.pageY;
  }
}
window.onmousemove = (e)=>{
  mouseCords.x_page_old = mouseCords.x_page;
  mouseCords.y_page_old = mouseCords.y_page;
  mouseCords.x_page = e.pageX;
  mouseCords.y_page = e.pageY;



  mouseCords.x_old = mouseCords.x;
  mouseCords.y_old = mouseCords.y;
  const x = e.offsetX;
  const y = e.offsetY;

  mouseCords.x = x;
  mouseCords.y = y;

  if(mouseCords.isDown){        
    const width = 10;
    if(mouseCords.whichClick === 1){
      drawLine(mouseCords.x_old,mouseCords.y_old,mouseCords.x, mouseCords.y,curentColorL,width);    
    }
    else if(mouseCords.whichClick === 3){
      drawLine(mouseCords.x_old,mouseCords.y_old,mouseCords.x, mouseCords.y,curentColorR,width); 
    }
  }

  if(mouseCords.isOver){
    doc_cords.innerHTML = `(${mouseCords.x}, ${mouseCords.y})px`;
  }
  // console.log(`${event.offsetX}, ${event.offsetY}`);
  // console.log(`${e.pageX}, ${e.pageY}, ${mouseCordsOnCanvas.isOnPage}`);
}
window.onmousedown = (e)=>{
  if(!mouseCords.isDownOnPage){
    mouseCords.isDownOnPage = true;
    mouseCords.whichClick = e.which;

    mouseCords.x_page = e.pageX;
    mouseCords.y_page = e.pageY;
    mouseCords.x_page_old = e.pageX;
    mouseCords.y_page_old = e.pageY;

  }
  else{

  }
}

window.onmouseup = function(e){
  mouseCords.isDown = false;  
  mouseCords.isDownOnPage = false;  

  var x = e.offsetX;
  var y = e.offsetY;

  mouseCords.x_old = mouseCords.x;
  mouseCords.y_old = mouseCords.y;

  mouseCords.x = x;
  mouseCords.y = y;
  // console.log(`UP: ${e.pageX}, ${e.pageY}`)
}

// function addP(x, y){
//   const newDiv = document.createElement("divf");
//   //const currentDiv = document.getElementById("div1");
//   document.body.insertBefore(newDiv, null);
//   console.dir(newDiv);
// }
// for(let p = 0;p <1300;p++)
// {
//   addP(1,1);
// }




canv.onmousedown = function(event) {
  const x = event.offsetX;
  const y = event.offsetY;
  mouseCords.isDown = true;
  mouseCords.x = x;
  mouseCords.y = y;
  mouseCords.x_old = x;
  mouseCords.y_old = y;
}


function drawLine(bx,by,ex,ey,lineColor,width=10){
  ctx.beginPath();
  ctx.moveTo(bx,by);
  ctx.lineTo(ex, ey);
  ctx.strokeStyle = lineColor;
  ctx.lineWidth = width;
  ctx.stroke();

  ctx.beginPath();
  ctx.fillStyle = lineColor;
  ctx.arc(bx, by, width/2, 0, 2 * Math.PI, true);
  ctx.fill();

  ctx.beginPath();
  ctx.fillStyle = lineColor;
  ctx.arc(ex, ey, width/2, 0, 2 * Math.PI, true);
  ctx.fill();
}

// console.dir(canv);